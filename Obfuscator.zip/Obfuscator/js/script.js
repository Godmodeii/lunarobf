const obfuscateUrl = 'https://bytesoftware.vercel.app/api/obfuscate';

async function obfuscate() {
    const input = document.getElementById('code-input');
    const output = document.getElementById('code-output');
    const loader = document.getElementById('loader');
    const btnText = document.getElementById('btn-text');
    const obfuscateBtn = document.getElementById('obfuscate-btn');
    const copyBtn = document.getElementById('copy-btn');
    const messageContainer = document.getElementById('message-container');

    const script = input.value.trim();
    if(!script) {
        output.value = "Please enter Lua code first.";
        showMessage("Please enter Lua code first.", "warning");
        return;
    }

    output.value = "Obfuscating...";
    obfuscateBtn.disabled = true;
    copyBtn.disabled = true;
    loader.classList.remove('hidden');
    btnText.textContent = 'Obfuscating...';
    hideMessage();

    try {
        const resp = await fetch(obfuscateUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                script
            })
        });

        const contentType = resp.headers.get('Content-Type') || '';
        const data = contentType.includes('json') ? await resp.json() : await resp.text();
        const parsed = typeof data === 'string' ? JSON.parse(data) : data;

        let obf = null;
        const keys = ['obfuscated', 'result', 'code', 'obf', 'payload', 'output', 'data', 'script'];
        for(const k of keys) {
            if(parsed[k] && typeof parsed[k] === 'string') {
                obf = parsed[k];
                break;
            }
        }

        if(!obf) {
            let longest = '';

            function walk(v) {
                if(typeof v === 'string' && v.length > longest.length) longest = v;
                else if(Array.isArray(v)) v.forEach(walk);
                else if(v && typeof v === 'object') Object.values(v).forEach(walk);
            }
            walk(parsed);
            obf = longest;
        }

        if(!obf) {
            output.value = "No obfuscated output found.";
            showMessage("No obfuscated output found.", "error");
            return;
        }

        obf = obf.replace(
            /--\[\[\s*v?1\.0\.0\s+https:\/\/wearedevs\.net\/obfuscator\s*\]\]/i,
            "--[[ Lunar Hub Obfuscator || Credits to Byt3c0de ]]"
        );

        output.value = obf;
        copyBtn.disabled = false;
        showMessage("Obfuscation complete!", "success");

    } catch(err) {
        output.value = "Error: " + err;
        showMessage("Error: " + err, "error");
    } finally {
        obfuscateBtn.disabled = false;
        loader.classList.add('hidden');
        btnText.textContent = 'Obfuscate Code';
    }

    function showMessage(text, type = "success") {
        messageContainer.textContent = text;
        messageContainer.className = 'mb-6 p-4 rounded-xl border-2 text-sm text-white font-medium shadow-md';
        if(type === "error") messageContainer.classList.add('border-red-500', 'bg-red-900/30');
        else if(type === "warning") messageContainer.classList.add('border-yellow-500', 'bg-yellow-900/30');
        else messageContainer.classList.add('border-green-500', 'bg-green-900/30');
        messageContainer.classList.remove('hidden', 'opacity-0');
        messageContainer.classList.add('opacity-100');
        setTimeout(() => {
            messageContainer.classList.remove('opacity-100');
            messageContainer.classList.add('opacity-0');
            setTimeout(() => messageContainer.classList.add('hidden'), 300);
        }, 5000);
    }

    function hideMessage() {
        messageContainer.classList.add('hidden', 'opacity-0');
    }
}

document.getElementById('obfuscate-btn').addEventListener('click', obfuscate);